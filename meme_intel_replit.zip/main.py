from __future__ import annotations
import os, time, asyncio
from pathlib import Path
from typing import Any
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field
from engine import Candle, evaluate_setup, risk_flags, opportunity_score
from adapters import BirdeyeAdapter, HeliusAdapter, XAdapter, x_items, social_metrics, extract_cas
from storage import Store

load_dotenv()
app = FastAPI(title="Meme Intel", version="1.0")
store = Store()
be = BirdeyeAdapter()
he = HeliusAdapter()
xa = XAdapter()

class AnalyzeReq(BaseModel):
    mint: str = Field(min_length=32, max_length=44)
    x_query: str = '(solana OR "pump.fun" OR memecoin OR $SOL) lang:en -is:retweet'

class XSearchReq(BaseModel):
    query: str
    max_results: int = 25

class PaperOpenReq(BaseModel):
    mint: str
    side: str = "LONG"
    entry: float
    qty: float
    note: str = ""

class PaperCloseReq(BaseModel):
    trade_id: int
    exit: float

def parse_candles(data):
    items = (data or {}).get("data",{}).get("items",[])
    return [Candle(ts=int(x["unix_time"]), o=float(x["o"]), h=float(x["h"]),
                   l=float(x["l"]), c=float(x["c"]), v=float(x.get("v",0)))
            for x in items]

def nested(data, *keys):
    cur=data
    for k in keys:
        if not isinstance(cur, dict): return None
        cur=cur.get(k)
    return cur

@app.get("/")
async def index():
    return FileResponse(Path(__file__).with_name("static")/"index.html")

@app.get("/api/health")
async def health():
    return {
        "status":"ONLINE",
        "sources":{
            "X": {"configured": xa.source.configured, "state":"READY" if xa.source.configured else "NOT_CONFIGURED"},
            "Birdeye":{"configured":be.source.configured, "state":"READY" if be.source.configured else "NOT_CONFIGURED"},
            "Helius":{"configured":he.source.configured, "state":"READY" if he.source.configured else "NOT_CONFIGURED"},
        },
        "server_time":int(time.time())
    }

@app.post("/api/x/search")
async def x_search(req: XSearchReq):
    payload, err = await xa.recent(req.query, req.max_results)
    if err:
        return {"state":err, "items":[]}
    items=x_items(payload)
    for i in items:
        i["ca_count"]=len(i["cas"])
    return {"state":"READY","items":items,"social":social_metrics(items)}

@app.post("/api/analyze")
async def analyze(req: AnalyzeReq):
    if not req.mint.strip():
        raise HTTPException(400,"Mint required")

    o_task=be.overview(req.mint)
    s_task=be.security(req.mint)
    c_task=be.creation(req.mint)
    ca_task=he.asset(req.mint)
    candles5_task=be.candles(req.mint,"5m",21600)
    candles1_task=be.candles(req.mint,"1m",3600)
    x_task=xa.recent(req.x_query,50)
    (overview,ov_err),(security,se_err),(creation,cr_err),(asset,ha_err),(d5,e5),(d1,e1),(xp,xerr)=await asyncio.gather(
        o_task,s_task,c_task,ca_task,candles5_task,candles1_task,x_task
    )

    c5=parse_candles(d5); c1=parse_candles(d1)
    setup=evaluate_setup(c5,c1) if c5 and c1 else None

    data = overview.get("data",{}) if isinstance(overview,dict) else {}
    sec = security.get("data",{}) if isinstance(security,dict) else {}
    social=x_items(xp) if not xerr else []
    sm=social_metrics(social)

    liquidity=data.get("liquidity")
    market_cap=data.get("marketCap")
    holder_conc=sec.get("top10HolderPercent")
    if isinstance(holder_conc,(int,float)) and holder_conc>1:
        holder_conc = holder_conc/100.0

    risk=risk_flags(
        liquidity_usd=liquidity,
        market_cap=market_cap,
        holder_concentration=holder_conc,
        mint_authority=bool(sec.get("mintAuthority")),
        freeze_authority=bool(sec.get("freezeAuthority")),
        social_domination=sm.get("domination")
    )

    technical=75 if setup and setup.state=="BREAKOUT_CONFIRMED" else 50 if setup and setup.state=="HIGHER_LOW" else 20
    social_velocity=min(100, (sm.get("mention_velocity") or 0)*10)
    liquidity_score=0 if liquidity is None else min(100, max(0, liquidity/500))
    penalty={"LOW":0,"UNKNOWN":15,"MEDIUM":20,"HIGH":40,"CRITICAL":80}.get(risk["overall"],15)
    score=opportunity_score(
        technical=technical,
        social_velocity=social_velocity,
        sentiment=sm.get("sentiment") or 50,
        liquidity=liquidity_score,
        corroboration=60 if not xerr and (xp or {}).get("data") else 0,
        risk_penalty=penalty,
        data_complete=not any([ov_err,se_err,e5,e1])
    )

    return {
        "mint":req.mint,
        "state":"READY" if any([overview,security,c5,c1,social,asset]) else "DATA NOT AVAILABLE",
        "setup":setup.dict() if setup else {"state":"DATA NOT AVAILABLE"},
        "overview": data if data else "DATA NOT AVAILABLE",
        "security": sec if sec else "DATA NOT AVAILABLE",
        "creation": (creation or {}).get("data","DATA NOT AVAILABLE") if isinstance(creation,dict) else "DATA NOT AVAILABLE",
        "asset": asset or "DATA NOT AVAILABLE",
        "social": sm,
        "risk": risk,
        "score": score,
        "sources":{
            "Birdeye": {"overview":ov_err or "READY","security":se_err or "READY","5m":e5 or "READY","1m":e1 or "READY","creation":cr_err or "READY"},
            "Helius": ha_err or "READY",
            "X": xerr or "READY"
        },
    }

@app.get("/api/paper/trades")
async def paper_trades():
    return {"trades":store.trades()}

@app.post("/api/paper/open")
async def paper_open(req: PaperOpenReq):
    return {"trade_id":store.add_trade(req.mint,req.side,req.entry,req.qty,req.note)}

@app.post("/api/paper/close")
async def paper_close(req: PaperCloseReq):
    return store.close_trade(req.trade_id,req.exit)

@app.get("/api/sources")
async def sources():
    return {
        "X":{"state":"READY" if xa.source.configured else "NOT_CONFIGURED"},
        "Birdeye":{"state":"READY" if be.source.configured else "NOT_CONFIGURED"},
        "Helius":{"state":"READY" if he.source.configured else "NOT_CONFIGURED"},
        "rule":"No missing provider data is substituted with made-up values."
    }
