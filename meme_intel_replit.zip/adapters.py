from __future__ import annotations
import os, re, time, hashlib
from typing import Any
import httpx

BIRDEYE = "https://public-api.birdeye.so"
X_API = "https://api.x.com/2"
HELIUS_RPC = "https://mainnet.helius-rpc.com"

CA_RE = re.compile(r"\b[1-9A-HJ-NP-Za-km-z]{32,44}\b")

class Source:
    def __init__(self, name, configured, reason=""):
        self.name = name
        self.configured = configured
        self.reason = reason

class BirdeyeAdapter:
    def __init__(self, key=None):
        self.key = key or os.getenv("BIRDEYE_API_KEY")
        self.source = Source("Birdeye", bool(self.key),
                             "BIRDEYE_API_KEY missing" if not self.key else "")
    async def _get(self, path, params):
        if not self.key: return None, "NOT_CONFIGURED"
        headers = {"X-API-KEY": self.key, "x-chain": "solana", "accept": "application/json"}
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get(BIRDEYE+path, params=params, headers=headers)
            if r.status_code >= 400:
                return None, f"HTTP_{r.status_code}"
            return r.json(), None
    async def overview(self, mint):
        return await self._get("/defi/token_overview", {"address": mint, "frames":"1m,5m,1h,24h"})
    async def security(self, mint):
        return await self._get("/defi/token_security", {"address": mint})
    async def creation(self, mint):
        return await self._get("/defi/token_creation_info", {"address": mint})
    async def candles(self, mint, interval="5m", seconds=21600):
        now = int(time.time())
        params = {"address": mint, "type": interval, "time_from": now-seconds, "time_to": now}
        return await self._get("/defi/v3/ohlcv", params)

class HeliusAdapter:
    def __init__(self, key=None):
        self.key = key or os.getenv("HELIUS_API_KEY")
        self.source = Source("Helius", bool(self.key),
                             "HELIUS_API_KEY missing" if not self.key else "")
    async def asset(self, mint):
        if not self.key: return None, "NOT_CONFIGURED"
        url = f"{HELIUS_RPC}/?api-key={self.key}"
        body = {"jsonrpc":"2.0","id":"meme-intel","method":"getAsset",
                "params":{"id":mint,"displayOptions":{"showFungible":True}}}
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.post(url, json=body)
            if r.status_code >= 400:
                return None, f"HTTP_{r.status_code}"
            j = r.json()
            return j.get("result"), None

class XAdapter:
    def __init__(self, token=None):
        self.token = token or os.getenv("X_BEARER_TOKEN")
        self.source = Source("X", bool(self.token),
                             "X_BEARER_TOKEN missing" if not self.token else "")
    async def recent(self, query, max_results=50):
        if not self.token: return None, "NOT_CONFIGURED"
        params = {
            "query": query,
            "max_results": min(max(10, int(max_results)), 100),
            "tweet.fields": "created_at,public_metrics,author_id,lang",
            "expansions": "author_id",
            "user.fields": "name,username,profile_image_url"
        }
        headers = {"Authorization": f"Bearer {self.token}"}
        async with httpx.AsyncClient(timeout=15) as c:
            r = await c.get(f"{X_API}/tweets/search/recent", params=params, headers=headers)
            if r.status_code >= 400:
                return None, f"HTTP_{r.status_code}:{r.text[:250]}"
            return r.json(), None

def extract_cas(text: str):
    return CA_RE.findall(text or "")

def x_items(payload):
    if not payload: return []
    users = {u["id"]:u for u in payload.get("includes",{}).get("users",[])}
    items = []
    for t in payload.get("data",[]):
        u = users.get(t.get("author_id"), {})
        pm = t.get("public_metrics",{}) or {}
        items.append({
            "id":t["id"], "text":t.get("text",""), "created_at":t.get("created_at"),
            "username":u.get("username",""), "name":u.get("name",""),
            "likes":pm.get("like_count",0), "reposts":pm.get("retweet_count",0),
            "replies":pm.get("reply_count",0), "quotes":pm.get("quote_count",0),
            "cas":extract_cas(t.get("text","")),
            "url":f"https://x.com/{u.get('username','i')}/status/{t['id']}"
        })
    return items

def social_metrics(items):
    if not items:
        return {"post_count":0,"mention_velocity":None,"sentiment":None,
                "domination":None,"duplicates":None}
    now = time.time()
    recent = [x for x in items if x.get("created_at") and
              (now-time.mktime(__import__("datetime").datetime.fromisoformat(
                  x["created_at"].replace("Z","+00:00")).timetuple())) <= 900]
    counts={}
    for x in recent:
        counts[x["username"]] = counts.get(x["username"],0)+1
    top = max(counts.values(), default=0)
    domination = top/max(1,len(recent))
    texts = [re.sub(r"\W+"," ",x["text"].lower()).strip() for x in recent]
    dup = 0
    if texts:
        dup = len(texts)-len(set(texts))
    # Tiny, conservative lexicon-based sentiment; not an LLM claim.
    pos_words = {"bullish","moon","breakout","buy","strong","send","pump","good"}
    neg_words = {"rug","scam","dump","bearish","sell","bad","dead"}
    pos=neg=0
    for t in texts:
        w=set(t.split())
        pos += len(w & pos_words); neg += len(w & neg_words)
    total=pos+neg
    sentiment = 50 if total==0 else 50 + 50*(pos-neg)/total
    return {
        "post_count":len(items),
        "mention_velocity":len(recent)/15,
        "sentiment":round(max(0,min(100,sentiment)),1),
        "domination":round(domination,3),
        "duplicates":dup
    }
