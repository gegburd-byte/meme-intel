const $=id=>document.getElementById(id);
let lastData=null;
function money(x){return x==null?"DATA NOT AVAILABLE":Number(x).toLocaleString(undefined,{maximumFractionDigits:8})}
function setDot(id,ok){$(id).className="dot "+(ok?"ok":"bad")}
function row(k,v,cls=""){return `<div class="row"><span>${k}</span><b class="${cls}">${v}</b></div>`}
async function health(){
  const r=await fetch("/api/health");const j=await r.json();
  $("health").textContent=j.status;
  for(const [k,id] of [["X","dotX"],["Birdeye","dotBE"],["Helius","dotHE"]]){
    const ok=j.sources[k].configured; setDot(id,ok); $("src"+(k==="Birdeye"?"BE":k==="Helius"?"HE":"X")).textContent=ok?"READY":"NOT_CONFIGURED";
  }
}
function renderSetup(s){
  $("setupState").textContent=s.state||"DATA NOT AVAILABLE";
  $("prevHigh").textContent=money(s.prev_high);
  $("higherLow").textContent=money(s.higher_low);
  $("stop").textContent=money(s.stop);
  $("setupWhy").textContent=s.last_reason||"—";
}
function renderScore(s){
  $("score").textContent=s?.score==null?"—":s.score+"/100";
  $("scoreRows").innerHTML = s?.components ? Object.entries(s.components).map(([k,v])=>row(k.replaceAll("_"," "),v.value+" / 100")).join("") : row("State","DATA NOT AVAILABLE");
}
function renderRisk(r){
  $("riskLevel").textContent=r?.overall||"DATA NOT AVAILABLE";
  $("riskRows").innerHTML=(r?.flags||[]).length ? r.flags.map(f=>row(f.code,f.level+" — "+f.reason, f.level==="CRITICAL"||f.level==="HIGH"?"bad":f.level==="MEDIUM"?"warn":"")).join("") : row("Flags","None returned");
}
function renderSocial(s){
  $("posts").textContent=s?.post_count??"—";
  $("vel").textContent=s?.mention_velocity==null?"DATA NOT AVAILABLE":s.mention_velocity.toFixed(2);
  $("sentiment").textContent=s?.sentiment==null?"DATA NOT AVAILABLE":s.sentiment;
  $("domination").textContent=s?.domination==null?"DATA NOT AVAILABLE":(s.domination*100).toFixed(1)+"%";
  $("dupes").textContent=s?.duplicates??"—";
}
function renderToken(o){
  $("tokenName").textContent=o?.symbol||o?.name||"—";
  $("tokenRows").innerHTML=row("Price",money(o?.price))+row("Liquidity",o?.liquidity==null?"DATA NOT AVAILABLE":"$"+Number(o.liquidity).toLocaleString())+row("Market cap",o?.marketCap==null?"DATA NOT AVAILABLE":"$"+Number(o.marketCap).toLocaleString())+row("24h volume",o?.v24hUSD==null?"DATA NOT AVAILABLE":"$"+Number(o.v24hUSD).toLocaleString());
}
function renderTweets(items){
  $("tweetCount").textContent=`${items.length} returned`;
  $("tweets").innerHTML=items.length?items.map(t=>`<div class="tweet">
    <div class="meta">@${t.username||"unknown"} · ${t.created_at||""} · ♥ ${t.likes} · ↻ ${t.reposts} · 💬 ${t.replies}</div>
    <p>${escapeHtml(t.text)}</p>
    ${t.cas?.length?`<div class="meta">CA: ${t.cas.join(", ")}</div>`:""}
    <a target="_blank" rel="noreferrer" href="${t.url}">open on X ↗</a>
  </div>`).join(""):`<div class="muted">No X results or X is not configured.</div>`;
}
function escapeHtml(x){return String(x).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
async function analyze(){
  const mint=$("mint").value.trim();if(!mint){alert("Paste a Solana mint/contract address.");return}
  $("setupState").textContent="LOADING…";
  const r=await fetch("/api/analyze",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({mint,x_query:$("query").value})});
  const j=await r.json(); lastData=j;
  if(!r.ok){alert(j.detail||"Analyze failed");return}
  renderSetup(j.setup);renderScore(j.score);renderRisk(j.risk);renderSocial(j.social);renderToken(typeof j.overview==="object"?j.overview:null);
  $("raw").textContent=JSON.stringify(j,null,2);
  const q=$("query").value;
  const xr=await fetch("/api/x/search",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({query:q,max_results:50)});
  const xj=await xr.json();renderTweets(xj.items||[]);
}
async function loadTrades(){
  const r=await fetch("/api/paper/trades");const j=await r.json();
  $("paperTrades").innerHTML=(j.trades||[]).map(t=>`<div class="trade"><span>#${t.id} ${t.side} ${t.mint.slice(0,6)}… entry ${money(t.entry)} ${t.closed_at?"closed":"OPEN"}</span><b class="${t.pnl>0?"good":t.pnl<0?"bad":""}">${t.pnl==null?"—":money(t.pnl)}</b></div>`).join("")||`<span class="muted">No paper trades.</span>`;
}
$("analyze").onclick=analyze;
$("paperOpen").onclick=async()=>{
  const mint=$("mint").value.trim();const entry=Number($("pEntry").value);const qty=Number($("pQty").value);
  if(!mint||!entry||!qty){alert("Enter mint, entry and qty.");return}
  await fetch("/api/paper/open",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({mint,entry,qty,side:"LONG",note:$("pNote").value})});
  loadTrades();
};
health();loadTrades();
setInterval(health,15000);
